export function makeData() {
  return [{
    id: 1,
    nombre: "Makeup",
  },
  {
    id: 2,
    nombre: "Skin Care",
  },
  {
    id: 3,
    nombre: "Accesorios",
  },
  {
    id: 4,
    nombre: "Bolsos",
  },
  {
    id: 5,
    nombre: "Ropa",
  },
  {
    id: 6,
    nombre: "Calzado",
  },
];
}
