export function makeData() {
  return [{
    codigo: 1,
    nombre: "Makeup",
  },
  {
    codigo: 2,
    nombre: "Skin Care",
  },
  {
    codigo: 3,
    nombre: "Accesorios",
  },
  {
    codigo: 4,
    nombre: "Bolsos",
  },
  {
    codigo: 5,
    nombre: "Ropa",
  },
  {
    codigo: 6,
    nombre: "Calzado",
  },
];
}
