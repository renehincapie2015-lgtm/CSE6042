import React, { Fragment } from "react";
import { CSSTransition, TransitionGroup  } from '../../../utils/TransitionWrapper';

import { Row, Col, Card, CardBody } from "reactstrap";

import DataTable from 'react-data-table-component';

import PageTitle from "../../../Layout/AppMain/PageTitle";

import { makeData } from "./utils";

export default class DataTableBasic extends React.Component {
  constructor() {
    super();
    this.state = {
      data: makeData(),
    };
  }

  render() {
    const { data } = this.state;

    const columns = [
      {
        name: "Codigo",
        id: "codigo",
        selector: row => row.codigo,
        sortable: true,
      },
      {
        name: "Nombre",
        selector: row => row.nombre,
        sortable: true,
      },
    ];

    return (
      <Fragment>
        <TransitionGroup>
          <CSSTransition component="div" classNames="TabsAnimation" appear={true}
            timeout={1500} enter={false} exit={false}>
            <div>
              <PageTitle heading="Formas de Pago"
                subheading="Tarjetas, pasarelas de pago, banca electronica."
                icon="pe-7s-medal icon-gradient bg-tempting-azure"/>
              <Row>
                <Col md="12">
                  <Card className="main-card mb-3">
                    <CardBody>
                      <DataTable data={data}
                        columns={columns}
                        pagination 
                      />
                    </CardBody>
                  </Card>
                </Col>
              </Row>
            </div> 
          </CSSTransition>
        </TransitionGroup>
      </Fragment>
    );
  }
}
