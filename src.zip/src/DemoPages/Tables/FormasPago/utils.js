export function makeData() {
  return [{
    codigo: 1,
    nombre: "Tarjeta Debito",
  },
  {
    codigo: 2,
    nombre: "Tarjeta Crebito",
  },
  {
    codigo: 3,
    nombre: "Pasarela de Pago",
  },
  {
    codigo: 4,
    nombre: "Efectivo",
  },
  {
    codigo: 5,
    nombre: "Cupon",
  },
  {
    codigo: 6,
    nombre: "Puntos",
  },
];
}
