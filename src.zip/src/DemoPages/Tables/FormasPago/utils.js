export function makeData() {
  return [{
    id: 1,
    nombre: "Tarjeta Debito",
  },
  {
    id: 2,
    nombre: "Tarjeta Crebito",
  },
  {
    id: 3,
    nombre: "Pasarela de Pago",
  },
  {
    id: 4,
    nombre: "Efectivo",
  },
  {
    id: 5,
    nombre: "Cupon",
  },
  {
    id: 6,
    nombre: "Puntos",
  },
];
}
