export function makeData() {
  return [{
    id: 2,
    tipoDocumento: "CC",
    numeroDocumento: 22222222,
    apellidos: "Batista",
    nombres: "Patricia",
    celular: "3122222222",
  },
  {
    id: 3,
    tipoDocumento: "CC",
    numeroDocumento: 3333333333,
    apellidos: "Hincapie",
    nombres: "Angela",
    celular: "31888888888",
  },
];
}
