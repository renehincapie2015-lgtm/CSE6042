export function makeData() {
  return [{
    codigo: 2,
    tipoDocumento: "CC",
    numeroDocumento: 22222222,
    apellidos: "Batista",
    nombres: "Patricia",
    celular: "3122222222",
  },
  {
    codigo: 3,
    tipoDocumento: "CC",
    numeroDocumento: 3333333333,
    apellidos: "Hincapie",
    nombres: "Angela",
    celular: "31888888888",
  },
];
}
