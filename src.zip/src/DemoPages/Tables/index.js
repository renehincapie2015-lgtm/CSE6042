import React, { Fragment } from "react";
import { Routes, Route } from "react-router-dom";

// Tables

import Administradores from "./Administradores";
import Clientes from "./Clientes";
import Categorias from "./Categorias";
import FormasPago from "./FormasPago";
import Productos from "./Productos";
// import DataTables from "./DataTables";
// import RegularTables from "./RegularTables";
//       <Route path="datatables" element={<DataTables />} />
//       <Route path="regulartables" element={<RegularTables />} />

const Tables = () => (
  <Fragment>
    <Routes>
      <Route path="consulta-administradores" element={<Administradores />} />
      <Route path="consulta-clientes" element={<Clientes />} />
      <Route path="consulta-categorias" element={<Categorias />} />
      <Route path="consulta-formas-pago" element={<FormasPago />} />
      <Route path="consulta-producto" element={<Productos />} />
    </Routes>
  </Fragment>
);

export default Tables;
