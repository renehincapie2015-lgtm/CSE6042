import React, { Fragment } from "react";
import { CSSTransition, TransitionGroup  } from '../../../utils/TransitionWrapper';

import { Row, Col, Card, CardBody } from "reactstrap";

import DataTable from 'react-data-table-component';

import PageTitle from "../../../Layout/AppMain/PageTitle";

import { makeData } from "./utils";

export default class DataTableBasic extends React.Component {
  constructor() {
    super();
    this.state = {
      data: makeData(),
    };
  }

  render() {
    const { data } = this.state;

    const columns = [
      {
        name: "Codigo",
        id: "codigo",
        selector: row => row.codigo,
        sortable: true,
      },
      {
        name: "TipoId",
        selector: row => row.tipoDocumento,
        sortable: true,
      },
      {
        name: "NroId",
        selector: row => row.numeroDocumento,
        sortable: true,
      },
      {
        name: "Apellidos",
        selector: row => row.apellidos,
        sortable: true,
      },
      {
        name: "Nombres",
        selector: row => row.nombres,
        sortable: true,
      },
      {
        name: "Celular",
        selector: row => row.celular,
        sortable: true,
      },
    ];

    return (
      <Fragment>
        <TransitionGroup>
          <CSSTransition component="div" classNames="TabsAnimation" appear={true}
            timeout={1500} enter={false} exit={false}>
            <div>
              <PageTitle heading="Administradores"
                subheading="Tramitan los pedidos."
                icon="pe-7s-medal icon-gradient bg-tempting-azure"/>
              <Row>
                <Col md="12">
                  <Card className="main-card mb-3">
                    <CardBody>
                      <DataTable data={data}
                        columns={columns}
                        pagination 
                      />
                    </CardBody>
                  </Card>
                </Col>
              </Row>
            </div> 
          </CSSTransition>
        </TransitionGroup>
      </Fragment>
    );
  }
}
