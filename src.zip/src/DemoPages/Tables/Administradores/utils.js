export function makeData() {
  return [{
    id: 1,
    tipoDocumento: "CC",
    numeroDocumento: 77777777,
    apellidos: "Hincapie",
    nombres: "Rene",
    celular: "3011111111",
  },
  {
    id: 2,
    tipoDocumento: "CC",
    numeroDocumento: 22222222,
    apellidos: "Batista",
    nombres: "Patricia",
    celular: "3122222222",
  },
];
}
