import React, { Fragment } from "react";
import DataTable from './Basic';

const DataTables = () => (
    <Fragment>
        <DataTable />
    </Fragment>
);

export default DataTables; 