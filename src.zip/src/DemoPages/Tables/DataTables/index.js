import React, { Fragment } from "react";
import DataTable from './Examples/Basic';

const DataTables = () => (
    <Fragment>
        <DataTable />
    </Fragment>
);

export default DataTables; 