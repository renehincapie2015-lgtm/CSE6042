import React, { useState } from "react";
import {
  Modal,
  ModalHeader,
  ModalBody,
  ModalFooter,
  Button,
  Form,
  Input,
  FormText
} from "reactstrap";

const ProductoModal = ({ visible, onClose, onSave, form, setForm, editingProduct }) => {
  const [errors, setErrors] = useState({})

  const validate = () => {
    let newErrors = {}

    if (!form.nombre || form.nombre.trim() === '') {
      newErrors.nombre = 'El nombre es obligatorio'
    }
    if (!form.categoria || form.categoria.trim() === '') {
      newErrors.categoria = 'La categoría es obligatoria'
    }
    if (form.valor === '' || isNaN(form.valor)) {
      newErrors.valor = 'El valor debe ser un número'
    } else if (form.valor <= 0) {
      newErrors.valor = 'El valor debe ser mayor que 0'
    }
    if (form.stock === '' || isNaN(form.stock)) {
      newErrors.stock = 'El stock debe ser un número'
    } else if (form.stock <= 0) {
      newErrors.stock = 'El stock debe ser mayor que 0'
    }

    setErrors(newErrors)
    return Object.keys(newErrors).length === 0 // true si no hay errores
  }

  const handleSave = () => {
    if (validate()) {
      onSave()
    }
  }

  return (
    <Modal visible={visible} onClose={onClose}>
      <ModalHeader closeButton>
        <strong>{editingProduct ? '✏️ Editar Producto' : '➕ Nuevo Producto'}</strong>
      </ModalHeader>
      <ModalBody>
        <Form>
          {/* Nombre */}
          <Input
            className="mb-1"
            label="Nombre"
            value={form.nombre}
            invalid={!!errors.nombre}
            onChange={(e) => setForm({ ...form, nombre: e.target.value })}
          />
          {errors.nombre && <FormText invalid>{errors.nombre}</FormText>}

          {/* Valor */}
          <Input
            className="mb-1"
            type="number"
            label="Valor"
            value={form.valor}
            invalid={!!errors.valor}
            onChange={(e) => setForm({ ...form, valor: Number(e.target.value) })}
          />
          {errors.valor && <FormText invalid>{errors.valor}</FormText>}

          {/* Categoría */}
          <Input
            className="mb-1"
            label="Categoría"
            value={form.categoria}
            invalid={!!errors.categoria}
            onChange={(e) => setForm({ ...form, categoria: e.target.value })}
          />
          {errors.categoria && <FormText invalid>{errors.categoria}</FormText>}

          {/* Stock */}
          <Input
            className="mb-1"
            type="number"
            label="Stock"
            value={form.stock}
            invalid={!!errors.stock}
            onChange={(e) => setForm({ ...form, stock: Number(e.target.value) })}
          />
          {errors.stock && <FormText invalid>{errors.stock}</FormText>}
        </Form>
      </ModalBody>
      <ModalFooter>
        <Button color="secondary" onClick={onClose}>
          Cancelar
        </Button>
        <Button color="primary" onClick={handleSave}>
          Guardar
        </Button>
      </ModalFooter>
    </Modal>
  )
}

export default ProductoModal