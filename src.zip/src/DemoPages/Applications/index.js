import React, { Fragment } from "react";
import { Routes, Route, Navigate } from "react-router-dom";
import { isAuthenticated } from "../../utils/auth";

// APPLICATIONS

import Mailbox from "./Mailbox/";
import Chat from "./Chat/";
import FaqSection from "./FaqSection/";

const Applications = () => (
  <Fragment>
    <Routes>
      <Route path="mailbox" element={isAuthenticated() ? <Mailbox /> : <Navigate to="/login" />} />
      <Route path="chat" element={isAuthenticated() ? <Chat /> : <Navigate to="/login" />} />
      <Route path="faq-section" element={isAuthenticated() ? <FaqSection /> : <Navigate to="/login" />} />
    </Routes>
  </Fragment>
);

export default Applications;
