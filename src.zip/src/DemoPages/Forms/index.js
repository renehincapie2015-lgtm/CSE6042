import React, { Fragment } from "react";
import { Routes, Route } from "react-router-dom";

// Forms

import Usuarios from "./Usuarios";

const Forms = () => (
  <Fragment>
    <Routes>
      {/* Forms */}
      <Route path="gestion-usuarios" element={<Usuarios />} />
    </Routes>
  </Fragment>
);

export default Forms;
