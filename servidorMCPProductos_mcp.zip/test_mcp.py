from fastmcp import FastMCP

mcp = FastMCP()

@mcp.tool(name="ping", description="Responde pong.")
def ping(_: dict) -> dict:
    return {"respuesta": "pong"}

if __name__ == "__main__":
    print ("Servidor MCP iniciado...")
    mcp.run()
