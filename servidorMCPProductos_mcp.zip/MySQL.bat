set MYSQL_HOST=localhost
set MYSQL_USER=root
set MYSQL_PASSWORD=luza0609
set MYSQL_NAME=bd_ecommerce_cse642
uv run fastmcp-mysql