uvicorn chatbot:app --reload --port 3002
