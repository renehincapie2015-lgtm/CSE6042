from fastapi import FastAPI, Request
from pydantic import BaseModel
import requests
from fastapi.middleware.cors import CORSMiddleware

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

FASTMCP_ENDPOINT = "https://mcp642renehincapie.fastmcp.app/mcp"

class ChatMessage(BaseModel):
    message: str

def detect_intent(message: str):
    lower = message.lower()

    if "ver productos" in lower or "listar" in lower:
        return {"tool": "listar_productos", "params": {}}

    import re
    match = re.search(r"producto (\d+)", lower)
    if match:
        return {"tool": "consultar_producto_por_id", "params": {"id": match.group(1)}}

    return None

@app.post("/chat")
async def chat_endpoint(chat: ChatMessage):
    intent = detect_intent(chat.message)

    if not intent:
        return {"reply": "No entendí tu solicitud. ¿Puedes reformularla?"}

    try:
        response = requests.post(
            FASTMCP_ENDPOINT,
            json={
                "jsonrpc": "2.0",
                "tool": intent["tool"],
                "params": intent["params"],
                "id": "chatbot-req-001"
            },
            headers={
                "Accept": "application/json, text/event-stream"
            })
#        return {"reply": response.json()}
        result = response.json().get("result")

        if isinstance(result, str): # Si es texto plano
            return {"reply": result}
        elif isinstance(result, list): # Si es lista de productos
            return {"reply": result}
        elif isinstance(result, dict): # Si es ficha de producto
            return {"reply": result}
        else: # Si no se reconoce
            return {"reply": f"Ocurrió un error al consultar los datos: {str(result)}"} #"Respuesta no reconocida"
    except Exception as e:
        return {"reply": f"Ocurrió un error al consultar los datos: {str(e)}"}
