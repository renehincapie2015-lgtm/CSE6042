from pydantic import BaseModel, Field, validator

class ProductoSchema(BaseModel):
    id: int | None = Field(None, description="ID del producto")
    nombre: str = Field(..., min_length=3, max_length=100, description="Nombre del producto")
    valor: float = Field(..., gt=0, description="El valor debe ser mayor que cero")
    categoria: int = Field(..., gt=0, description="La categoria debe ser mayor que cero")
    stock: int = Field(..., gt=0, description="El stock debe ser mayor que cero")

    class Config:
        orm_mode = True
