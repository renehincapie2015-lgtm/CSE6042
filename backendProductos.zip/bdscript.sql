-- Crear la base de datos y tabla
CREATE DATABASE IF NOT EXISTS bd_ecommerce_cse642;
USE tienda;

CREATE TABLE productos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(255) NOT NULL,
    valor DECIMAL(10,2) NOT NULL,
    categoria INT NOT NULL,
    stock INT NOT NULL
);


INSERT INTO productos (id, nombre, valor, categoria, stock) VALUES
('1', 'Maquillaje', 2.49, 1, 100),
('2', 'Delineador', 1.25, 1, 50),
('3', 'Humectante', 1.74, 2, 75),
('4', 'Mascara', 17.43, 2, 25),
('5', 'Aretes', 1.74, 3, 150),
('6', 'Collar', 7.47, 3, 30),
('7', 'Cuero', 74.73, 4, 20),
('8', 'Pantalon', 24.91, 5, 110),
('9', 'Falda', 29.89, 5, 200),
('10', 'Tennis', 12.45, 6, 600),
('11', 'Zapatos', 19.93, 6, 300),
('12', 'Bronceador', 8.5, 6, 350);
